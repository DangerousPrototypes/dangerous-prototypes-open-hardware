#!/bin/perl

foreach $oldname (@ARGV) {
    $oldname =~ /([a-z]+)(