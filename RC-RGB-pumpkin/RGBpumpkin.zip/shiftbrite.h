void rgbtest(void);
void writeBit(unsigned char c);
void writebyte(unsigned char c);
void write10Bits(unsigned int i);
void shiftBriteColor(unsigned int r, unsigned int g, unsigned int b);
volatile void delay(unsigned char c);
void SetupShiftBrite(void);
void storm(void);
