void ProcessIR(void);
void IRdecoderInterruptHandlerHigh (void);
void SetupRC5(void);
void IRmanString(void);
