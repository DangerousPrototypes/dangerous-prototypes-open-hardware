#ifndef KBHIT_H_INCLUDED
#define KBHIT_H_INCLUDED

#ifndef KBHITh
#define KBHITh

#include <curses.h>
#include <stdio.h>

int      kbhit(void);

#endif

#endif // KBHIT_H_INCLUDED
